<?php
return[
    'host' => 'localhost',
    'db_name' => 'seu_banco',
    'username' => 'usuario',
    'password' => 'senha'
];