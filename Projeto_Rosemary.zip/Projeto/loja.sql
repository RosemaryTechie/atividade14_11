create database loja;
use loja;
create table produtos (
	id int auto_increment primary key,
	nome varchar(100) not null,
	descricao text,
	preco decimal(10,2),
	quantidade int,
	data_adicao date
);

insert into produtos (nome, descricao, preco, quantidade, data_adicao)
values ('Geladeira', 'Geladeira Eletrolux Cycle Defrost 260l freezer com capacidade 53l duas portas branca', 6199.00, 100, CURDATE()),
('Forno Eletrico', 'Voltagem 220V capacidade 3 bandeijas Aço inoxidável', 2630.32, 100, CURDATE()),
('Máquina de lavar', 'Voltagem 110V capacidade 15kg Essential Care com cesto inox Jet&Clean', 2049.00, 100, CURDATE()),
('Fogão', 'Mesa de vidro time Digital Bivolt Acendemento Automático a Gás', 1689.00, 100, CURDATE()),
('air fryer', 'Painel Digital, Programável, Temporizador, Controlo de temperatura, Desligamento automático, Dimensões do produto 32P x 36,1L x 36A centímetros ', 539.00, 100, CURDATE());
